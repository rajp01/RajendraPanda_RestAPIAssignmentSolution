package com.gl.employeesvc.EmployeesSvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
